Run the predicate.py in any python ide 

After running it it will ask to "Enter your formula"
Enter the formula as a string
It will provide the output of the formula with proper paranthesis placed at right position